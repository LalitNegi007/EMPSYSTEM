﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VishvajeetCascad.Models;

namespace VishvajeetCascad.Respository.Contract
{
    public interface IRestorent
    {
        List<Starter> GetStarters();
        List<MainCourse> GetMaincourse();
        List<Sweat> GetSweats();
        List<Drink> GetDrinks();
    }
}
