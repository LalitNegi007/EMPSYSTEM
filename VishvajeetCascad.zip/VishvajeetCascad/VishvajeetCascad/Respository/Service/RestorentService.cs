﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VishvajeetCascad.Models;
using VishvajeetCascad.Respository.Contract;

namespace VishvajeetCascad.Respository.Service
{  
    public class RestorentService : IRestorent
    {
        private AppDbContext dbcon;
        public RestorentService(AppDbContext con) 
        {
            dbcon = con;
        }
        public List<Drink> GetDrinks()
        {
            var d = dbcon.drinks.ToList();
            return d;
        }

        public List<MainCourse> GetMaincourse()
        {
            var m = dbcon.mainCourses.ToList();
            return m;
        }

        public List<Starter> GetStarters()
        {
            var s= dbcon.starters.ToList();
            return s;
        }

        public List<Sweat> GetSweats()
        {
            var sw= dbcon.sweats.ToList();
            return sw;
        }
    }
}
