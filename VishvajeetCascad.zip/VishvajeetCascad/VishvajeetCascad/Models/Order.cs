﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VishvajeetCascad.Models
{
    public class Order
    {
        public int Id { get; set; }
        public string Starter { get; set; }
        public string MainCourse { get; set; }
        public string Sweat { get; set; }
        public string Drink { get; set; }
        public long total { get; set; }
    }
}
