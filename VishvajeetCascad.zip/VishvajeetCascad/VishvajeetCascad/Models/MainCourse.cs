﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VishvajeetCascad.Models
{
    public class MainCourse
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public long Price { get; set; }
    }
}
