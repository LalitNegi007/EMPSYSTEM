﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VishvajeetCascad.Respository.Contract;

namespace VishvajeetCascad.Controllers
{
    public class RestorentController : Controller
    {
        private IRestorent restorentService;
        public RestorentController(IRestorent service)  
        {
            restorentService = service;
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult GetStarter()
        {
            var starters = restorentService.GetStarters();
            return Json(starters);
        }
        public IActionResult GetDrink()
        {
            var drinks = restorentService.GetDrinks();
            return Json(drinks);
        }
        public IActionResult GetSweat()
        {
            var sweats = restorentService.GetSweats();
            return Json(sweats);
        }
        public IActionResult GetMainCourse()
        {
            var mainCourses = restorentService.GetMaincourse();
            return Json(mainCourses);
        }
    }
}
